#!/bin/bash
set -eu -o pipefail
exec > /evidence/setup.log 2>&1
export DEBIAN_FRONTEND=noninteractive DOTNET_CLI_TELEMETRY_OPTOUT=1
apt-get update -qq
apt-get install -y --no-install-recommends python3-venv poppler-utils openjdk-17-jdk-headless fontconfig libreoffice-core=4:24.2.7-0ubuntu0.24.04.7 libreoffice-writer=4:24.2.7-0ubuntu0.24.04.7
git -c safe.directory=/input/.git clone --depth 1 --branch v1.6.2 file:///input /work
cd /work
python3 -m venv /venv
/venv/bin/pip install -r eng/comparison-requirements.txt
python3 eng/prepare-comparison-poi.py
echo READY
