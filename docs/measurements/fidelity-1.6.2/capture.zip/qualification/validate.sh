#!/bin/bash
set -euo pipefail
exec > /evidence/validation.log 2>&1
export DOTNET_CLI_TELEMETRY_OPTOUT=1
cd /work
mkdir -p /schema
cp docs/measurements/roadmap-138-initial/schema-check-project.txt /schema/check.csproj
sed 's/count == 36/count == 40/' docs/measurements/roadmap-138-initial/schema-check-source.txt > /schema/Program.cs
dotnet run -c Release --project /schema/check.csproj -- /work/tests/wordnet.Conversion.Tests/Fixtures/Comparison /work/tests/wordnet.Conversion.Tests/Fixtures/Fidelity103 /work/docs/measurements/roadmap-138-combination-baseline/fixtures > /evidence/schema.txt
project=tests/wordnet.Conversion.Tests
filter='FullyQualifiedName~ContentControlWordVariantsTests|FullyQualifiedName~ReviewWorkflowTests.ReviewDisplay|FullyQualifiedName~DecidedFragmentExportsOneVersion|FullyQualifiedName~FieldFragmentsRequireExplicitCachePolicy'
for mode in source package; do
  if [ ! -d "/check-$mode" ]; then git -C /work worktree add --detach "/check-$mode" v1.6.2; fi
  cd "/check-$mode"
  cp /input/$project/ContentControlWordVariantsTests.cs /input/$project/ReviewWorkflowTests.Display.cs "$project/"
  options=()
  if [ "$mode" = source ]; then
    dotnet restore "$project" --locked-mode
  else
    options=(-p:WordnetPackageVersion=1.6.2)
    export NUGET_PACKAGES=/run162/package-cache
    dotnet restore "$project" "${options[@]}" --configfile /run162/package-project/NuGet.Config
    dotnet restore "$project" "${options[@]}" --configfile /run162/package-project/NuGet.Config --locked-mode
  fi
  dotnet test "$project" -c Release -f net10.0 --no-restore "${options[@]}" --filter "$filter" --logger "trx;LogFileName=$mode.trx" --results-directory /evidence/controls
  sha256sum "$project"/bin/Release/net10.0/{wordnet.dll,wordnet.Fonts.dll,wordnet.Conversion.Tests.dll} > "/evidence/$mode-assemblies.txt"
done
echo COMPLETE
