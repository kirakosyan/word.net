#!/bin/bash
set -eu -o pipefail
exec > /evidence/measure.log 2>&1
cd /work
export DOTNET_CLI_TELEMETRY_OPTOUT=1
/venv/bin/python /input/eng/refresh-fidelity-baseline.py --repository /work --commit d95225937b49dc3b0507fc87928b92fe86dd78ee --output /run162 --poi-classpath /work/artifacts/comparison-poi --reductions /work/tests/wordnet.Conversion.Tests/Fixtures/Fidelity103/manifest.json --combinations /work/docs/measurements/roadmap-138-combination-baseline/fixtures/manifest.json
echo COMPLETE
